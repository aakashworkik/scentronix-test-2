var mymodule = require('servermodule')
var test_1 = mymodule.findServer([
    {
      "url": "https://does-not-work.perfume.new",
      "priority": 1
    },
    {
      "url": "https://gitlab.com",
      "priority": 4
    },
    {
      "url": "http://app.scnt.me",
      "priority": 3
    },
    {
      "url": "https://offline.scentronix.com",
      "priority": 2
    }
  ]);

var test_2 = mymodule.findServer([
    {
        "url": "https://www.myntra.com",
        "priority": 3
    },
    {
        "url": "https://www.amazon.com",
        "priority": 2
    },{
        "url": "https://www.flipkart.com",
        "priority": 1
    }
  ]);

test_1.then((result) => console.log("test_1 -> ", result)).catch((err) => console.log("test_1 -> ", err))

test_2.then((result) => console.log("test_2 -> ", result)).catch((err) => console.log("test_2 -> ", err))
